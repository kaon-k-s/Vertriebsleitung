﻿namespace Vertriebsleitung.Models
{
    public class Artikel
    {
        public int Id { get; set; }

        public string? ArtNr { get; set; }
        public string? ArtBezeichnung { get; set; }
        public string? ArtBescrheibung { get; set; }
        public decimal ArtPreis { get; set; }
        public string? ArtFarbe { get; set; }
        public string? ArtMaterialien { get; set; }
        public decimal ArtBreite { get; set; }
        public decimal ArtTiefe { get; set; }
        public decimal ArtHoehe { get; set; }
        public int ArtAufLager { get; set; }
    }
}
