﻿using Microsoft.EntityFrameworkCore;

namespace Vertriebsleitung.Models
{
    public class VertriebsleitungDbContext :DbContext
    {
        public DbSet<Artikel> Artikelliste { get; set; }

        public VertriebsleitungDbContext(DbContextOptions<VertriebsleitungDbContext> options)
            : base(options) 
        {

        }
    }
}
