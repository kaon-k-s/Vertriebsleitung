﻿using MySql.Data.MySqlClient;

namespace Vertriebsleitung.Models
{
    public class Datenbank
    {
        // Deklaration der MySQL-Verbindung
        private MySqlConnection con;

        // Konstruktor der Klasse Datenbank, der die Verbindungsinformationen initialisiert
        public Datenbank()
        {
            string conStr = "SERVER=localhost;DATABASE=Vertriebsleitung; UID=root;PASSWORD=''";
            con = new MySqlConnection(conStr);
        }

        // Methode zum Öffnen der Verbindung zur Datenbank
        private void oeffnen()
        {
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                // Handle exceptions later
            }
        }

        // Methode zum Schließen der Verbindung zur Datenbank
        private void schliessen()
        {
            if (con != null)
            {
                try
                {
                    con.Close();
                }
                catch (Exception ex)
                {
                    // Handle exceptions later
                }
            }
        }

        // Methode zum Speichern der Artikel in der Datenbank
        public void SpeichernArtikel(Artikel artikel)
        {
            try
            {
                oeffnen();
                MySqlCommand cmd = con.CreateCommand();
                string s;

                s = string.Format("INSERT INTO artikel " +
                    "VALUES(NULL, '{0}', '{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}');",
                        artikel.ArtNr, artikel.ArtBezeichnung, artikel.ArtBescrheibung, artikel.ArtPreis, 
                        artikel.ArtFarbe, artikel.ArtMaterialien, artikel.ArtBreite,
                         artikel.ArtTiefe, artikel.ArtHoehe, artikel.ArtAufLager);

                cmd.CommandText = s;
                cmd.ExecuteNonQuery();
                schliessen();
            }
            catch (Exception ex)
            {
                // Handle exceptions later
            }
        }
    }
}
