using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Vertriebsleitung.Models;

namespace Vertriebsleitung.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly VertriebsleitungDbContext _context;

        public HomeController(ILogger<HomeController> logger, VertriebsleitungDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Bestellungen()
        {
            return View();
        }

        public IActionResult BearbeitenBestellung()
        {
            return View();
        }

        public IActionResult Kunden()
        {
            return View();
        }

        public IActionResult BearbeitenKunde()
        {
            return View();
        }

        public IActionResult Artikelliste()
        {
            return View();
        }

        public IActionResult BearbeitenArtikel()
        {
            return View();
        }

        public IActionResult BearbeitenArtikelForm(Artikel artikel)
        {
            _context.Artikelliste.Add(artikel);
            _context.SaveChanges();
            return RedirectToAction("Artikelliste");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
