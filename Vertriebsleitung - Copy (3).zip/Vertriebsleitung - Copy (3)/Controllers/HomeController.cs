using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Vertriebsleitung.Models;

namespace Vertriebsleitung.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Bestellungen()
        {
            return View();
        }

        public IActionResult BearbeitenBestellung()
        {
            return View();
        }

        public IActionResult Kunden()
        {
            return View();
        }

        public IActionResult BearbeitenKunde()
        {
            return View();
        }

        public IActionResult Artikelliste()
        {
            return View();
        }

        public IActionResult BearbeitenArtikel()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
