﻿namespace Vertriebsleitung.Models
{
    public class Artikel
    {
        private int artId;
        private int artNr;
        private string? artName;
        private string? artBescrheibung;
        private decimal artPreis;
        private string? artFarbe;
        private string? artMaterialien;
        private decimal artBreite;
        private decimal artTiefe;
        private decimal artHoehe;
        private int aufLager;

        // Eigenschaften für öffentliche Zugriffe auf die privaten Variablen
        public int ArtId { get => artId; set => artId = value; }
        public int ArtNr { get => artNr; set => artNr = value; }
        public string? ArtName { get => artName; set => artName = value; }
        public string? ArtBescrheibung { get => artBescrheibung; set => artBescrheibung = value; }
        public decimal ArtPreis { get => artPreis; set => artPreis = value; }
        public string? ArtFarbe { get => artFarbe; set => artFarbe = value; }
        public string? ArtMaterialien { get => artMaterialien; set => artMaterialien = value; }
        public decimal ArtBreite { get => artBreite; set => artBreite = value; }
        public decimal ArtTiefe { get => artTiefe; set => artTiefe = value; }
        public decimal ArtHoehe { get => artHoehe; set => artHoehe = value; }
        public int AufLager { get => aufLager; set => aufLager = value; }


        // Konstruktor der Klasse Artikel
        public Artikel(int artId, int artNr, string artName, string artBescrheibung, decimal artPreis, 
            string artFarbe, string artMaterialien, decimal artBreite, decimal artTiefe, decimal artHoehe, int aufLager)
        {
            ArtId = artId;
            ArtNr = artNr;
            ArtName = artName;
            ArtBescrheibung = artBescrheibung;
            ArtPreis = artPreis;
            ArtFarbe = artFarbe;
            ArtMaterialien = artMaterialien;
            ArtBreite = artBreite;
            ArtTiefe = artTiefe;
            ArtHoehe = artHoehe;
            AufLager = aufLager;
        }
    }
}
