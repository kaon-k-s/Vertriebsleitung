using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Vertriebsleitung.Models;

namespace Vertriebsleitung.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly VertriebsleitungDbContext _context;

        public HomeController(ILogger<HomeController> logger, VertriebsleitungDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // Bestellung
        public IActionResult Bestellungen()
        {
            return View();
        }

        public IActionResult BearbeitenBestellung()
        {
            return View();
        }

        // Kunde
        public IActionResult Kunden()
        {
            var allKunden = _context.Kundes.ToList();
            return View(allKunden);
        }

        public IActionResult BearbeitenKunde(int? id)
        {
            if (id != null)
            {
                // editing -> load an article by id
                var kundeInDb = _context.Kundes.SingleOrDefault(kunde => kunde.Id == id);
                return View(kundeInDb);
            }
            return View();
        }

        public IActionResult BearbeitenKundeForm(Kunde kunde)
        {
            if (kunde.Id == 0)
            {
                // Erstellen
                _context.Kundes.Add(kunde);
            }
            else
            {
                // Bearbeiten
                _context.Kundes.Update(kunde);
            }

            _context.SaveChanges();
            return RedirectToAction("Kunden");
        }

        public IActionResult LoeschenKunde(int? id)
        {
            if (id != null)
            {
                var kundeInDb = _context.Kundes.SingleOrDefault(kunde => kunde.Id == id);
                _context.Kundes.Remove(kundeInDb);
                _context.SaveChanges();
                return RedirectToAction("Kunden");
            }
            return RedirectToAction("BearbeitenKunde");
        }

        // Artikel
        public IActionResult Artikelliste()
        {
            var allArtikels = _context.Artikels.ToList();
            return View(allArtikels);
        }

        public IActionResult BearbeitenArtikel(int? id)
        {
            if (id != null) 
            {
                // editing -> load an article by id
                var artikelInDb = _context.Artikels.SingleOrDefault(artikel => artikel.Id == id);
                return View(artikelInDb);
            }
            return View();
        }

        public IActionResult BearbeitenArtikelForm(Artikel artikel)
        {
            if(artikel.Id == 0)
            {
                // Erstellen
                _context.Artikels.Add(artikel);
            }
            else
            {
                // Bearbeiten
                _context.Artikels.Update(artikel);
            }

            _context.SaveChanges();
            return RedirectToAction("Artikelliste");
        }

        public IActionResult LoeschenArtikel(int? id)
        {
            if (id != null)
            {
                var artikelInDb = _context.Artikels.SingleOrDefault(artikel => artikel.Id == id);
                _context.Artikels.Remove(artikelInDb);
                _context.SaveChanges();
                return RedirectToAction("Artikelliste");
            }
            return RedirectToAction("BearbeitenArtikel");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
