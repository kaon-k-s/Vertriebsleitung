﻿namespace Vertriebsleitung.Models
{
    public class Kunde
    {
        private int kundId;

        // Eigenschaften für öffentliche Zugriffe auf die privaten Variablen
        public int KundId { get => kundId; set => kundId = value; }

        // Konstruktor der Klasse Kunde
        public Kunde(int kundId)
        {
            KundId = kundId;
        }
    }
}
