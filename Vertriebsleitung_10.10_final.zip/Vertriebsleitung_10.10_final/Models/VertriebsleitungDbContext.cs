﻿using Microsoft.EntityFrameworkCore;

namespace Vertriebsleitung.Models
{
    public class VertriebsleitungDbContext :DbContext
    {
        public DbSet<Artikel> Artikels { get; set; }
        public DbSet<Kunde> Kundes { get; set; }

        public VertriebsleitungDbContext(DbContextOptions<VertriebsleitungDbContext> options)
            : base(options) 
        {

        }
    }
}
