﻿namespace Vertriebsleitung.Models
{
    public class Kunde
    {
        public int Id { get; set; }

        public string? KName { get; set; }
        public string? KEmail { get; set; }
        public string? KTelefonnummer { get; set; }
        public string? KStrasse { get; set; }
        public string? KHaus { get; set; }
        public string? KPLZ { get; set; }
        public string? KOrt { get; set; }
    }
}
