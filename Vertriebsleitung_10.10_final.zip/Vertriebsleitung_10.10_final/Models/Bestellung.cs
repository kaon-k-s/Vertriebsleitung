﻿namespace Vertriebsleitung.Models
{
    public class Bestellung
    {
        private int bestId;

        // Eigenschaften für öffentliche Zugriffe auf die privaten Variablen
        public int BestId { get => bestId; set => bestId = value; }

        // Konstruktor der Klasse Bestellung
        public Bestellung(int bestId)
        {
            BestId = bestId;
        }
    }
}
